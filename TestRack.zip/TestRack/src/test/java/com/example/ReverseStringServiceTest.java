package com.example;

import com.example.ReverseStringService;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

public class ReverseStringServiceTest {

    private ReverseStringService reverseStringService;

    @Before
    public void setup() {
        reverseStringService = new ReverseStringService();
    }

    @Test
    public void reverseWords_shouldReverseTheInputStringProvided() {
        assertEquals(reverseStringService.reverseWords("Iam an Indian"), "Indian an Iam");

    }

    @Test
    public void reverseWords_shouldReturnTheInputPassedIfItIsAnEmptyString() {
        assertEquals(reverseStringService.reverseWords(""), "");

    }

    @Test
    public void reverseWords_shouldReturnTheInputPassedIfItIsASpace() {
        assertEquals(reverseStringService.reverseWords(" "), " ");

    }

    @Test
    public void reverseWords_shouldReturnTheInputPassedIfItIsNull() {
        assertNull(reverseStringService.reverseWords(null));

    }

}