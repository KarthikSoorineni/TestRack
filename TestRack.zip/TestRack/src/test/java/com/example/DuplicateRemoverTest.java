package com.example;

import com.example.DuplicateRemover;
import org.junit.Before;
import org.junit.Test;

import java.util.List;

import static org.junit.Assert.assertTrue;

public class DuplicateRemoverTest {

    private DuplicateRemover duplicateRemover;

    @Before
    public void setup() {
        duplicateRemover = new DuplicateRemover();
    }

    @Test
    public void remove_shouldReturnUniqueElementsFromTheInputArray() {
        Integer[] duplicateElements = {1, 1, 2, 1, 2, 3, 4, 4, 5};
        Integer[] expectedUniqueElements = {1, 2, 3, 4, 5};
        final List<Integer> uniqeElements = duplicateRemover.getListOfUniqeElements(duplicateElements);
        for (int i = 0; i < expectedUniqueElements.length; i++) {
            assertTrue(uniqeElements.get(i).equals(expectedUniqueElements[i]));
        }
    }

    @Test
    public void remove_shouldReturnEmptyListIfTheInputPassedIsANullArray() {
        Integer[] duplicateElements = null;
        final List<Integer> uniqeElements = duplicateRemover.getListOfUniqeElements(duplicateElements);
        assertTrue(uniqeElements.isEmpty());
    }
}