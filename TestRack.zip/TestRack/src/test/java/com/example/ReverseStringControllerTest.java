package com.example;

import com.example.ReverseStringController;
import com.example.ReverseStringService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class ReverseStringControllerTest {

    @InjectMocks
    private ReverseStringController reverseStringController;

    @Mock
    private ReverseStringService reverseStringService;

    @Test
    public void getReversedString_shouldInvokeTheReverseStringServiceToReversTheInputPassed() {
        final String input = "Iam an Indian";
        reverseStringController.getReversedString(input);
        verify(reverseStringService).reverseWords(input);
    }

    @Test
    public void getReversedString_shouldReturnTheResponseAsTheReversedInput() {
        final String input = "Iam an Indian";
        final String reversedInput = "Indian an Iam";
        when(reverseStringService.reverseWords(input)).thenReturn(reversedInput);
        assertEquals(reverseStringController.getReversedString(input).getBody(), reversedInput);
    }

    @Test
    public void getReversedString_shouldReturnTheResponseStatusCodeAsOK() {
        final String input = "Iam an Indian";
        final String reversedInput = "Indian an Iam";
        when(reverseStringService.reverseWords(input)).thenReturn(reversedInput);
        assertEquals(reverseStringController.getReversedString(input).getStatusCode(), HttpStatus.OK);
    }

    @Test
    public void getReversedString_shouldReturnTheResponseStatusCodeValuesAs200() {
        final String input = "Iam an Indian";
        final String reversedInput = "Indian an Iam";
        when(reverseStringService.reverseWords(input)).thenReturn(reversedInput);
        assertEquals(reverseStringController.getReversedString(input).getStatusCodeValue(), 200);
    }
}