package com.example;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

public class DuplicateRemover {

    public List<Integer> getListOfUniqeElements(Integer[] input) {
        if (Objects.isNull(input)) {
            return Collections.emptyList();
        }
        final List<Integer> inputElements = Arrays.asList(input);
        final List<Integer> uniqueElements = new ArrayList<>();
        inputElements.forEach(inputElement -> {
            if (!uniqueElements.contains(inputElement)) {
                uniqueElements.add(inputElement);
            }
        });
        return uniqueElements;
    }
}
