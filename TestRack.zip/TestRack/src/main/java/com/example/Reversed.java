package com.example;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Reversed {
    private String reversed;

    public Reversed(String reversed) {
        this.reversed = reversed;
    }

    @JsonProperty("reversed")
    public String getReversed() {
        return this.reversed;
    }
}
