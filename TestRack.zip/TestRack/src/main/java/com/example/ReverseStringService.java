package com.example;

import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

@Service
public class ReverseStringService {

    private static final String EMPTY_STRING = "";
    private static final String SPACE = " ";

    public String reverseWords(String input) {

        if (StringUtils.isEmpty(input) || StringUtils.isEmpty(input.trim())) {
            return input;
        }
        final String[] individualWords = input.split("\\s");
        return getReversedStringFrom(individualWords);
    }

    private String getReversedStringFrom(String[] individualWords) {
        String reversedString = EMPTY_STRING;
        for (int i = 0; i < individualWords.length; i++) {
            if (i == individualWords.length - 1)
                reversedString = individualWords[i].concat(reversedString);
            else
                reversedString = SPACE.concat(individualWords[i]).concat(reversedString);
        }
        return reversedString;
    }
}

